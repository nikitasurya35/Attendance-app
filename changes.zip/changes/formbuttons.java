package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;

import com.example.androidattendancesystem.R;

public class formbuttons extends Activity {
    Button mentor;
    Button examform;
    Button admissionform;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.formbuttons);

        mentor = (Button)findViewById(R.id.buttonmentor);
        mentor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(formbuttons.this, mentoractivity.class);
                startActivity(intent);
            }
        });

        examform = (Button)findViewById(R.id.buttonexam);
        examform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(formbuttons.this, mentoractivity.class);
                startActivity(intent);
            }
        });

        admissionform = (Button)findViewById(R.id.buttonadmission);
        admissionform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(formbuttons.this, mentoractivity.class);
                startActivity(intent);
            }
        });
    }
}
