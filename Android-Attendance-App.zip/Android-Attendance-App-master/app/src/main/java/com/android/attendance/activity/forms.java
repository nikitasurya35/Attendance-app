package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;



import com.example.androidattendancesystem.R;

public class forms extends Activity {
    Button mentor;
    Button examform;
    Button admissionform;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forms);

        mentor = (Button)findViewById(R.id.b3);
        mentor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(forms.this, forms_link.class);
                startActivity(intent);
            }
        });

        examform = (Button)findViewById(R.id.b4);
        examform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(forms.this, forms_link.class);
                startActivity(intent);
            }
        });

        admissionform = (Button)findViewById(R.id.b5);
        admissionform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(forms.this, forms_link.class);
                startActivity(intent);
            }
        });
    }
}
