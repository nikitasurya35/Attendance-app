package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.androidattendancesystem.R;

public class forms_link extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form_link);


        TextView txt= (TextView) findViewById(R.id.tv1); //txt is object of TextView
        txt.setMovementMethod(LinkMovementMethod.getInstance());
        txt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                browserIntent.setData(Uri.parse("https://www.google.com/forms/about/"));
                startActivity(browserIntent);
            }
        });

        TextView txt1= (TextView) findViewById(R.id.tv2); //txt is object of TextView
        txt1.setMovementMethod(LinkMovementMethod.getInstance());
        txt1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                browserIntent.setData(Uri.parse("https://old.mu.ac.in/student-section/examination/"));
                startActivity(browserIntent);
            }
        });

        TextView txt2= (TextView) findViewById(R.id.tv3); //txt is object of TextView
        txt2.setMovementMethod(LinkMovementMethod.getInstance());
        txt2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                browserIntent.setData(Uri.parse("https://fcrit.ac.in/"));
                startActivity(browserIntent);
            }
        });

    }
}
